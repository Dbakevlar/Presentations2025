param(
  [bool]$Enable = $true,
  [string]$HostName = 'localhost',
  [int]$Port = 5432,
  [string]$Database = 'demo',
  [string]$User = 'postgres',
  [string]$Password = $env:PGPASSWORD
)

# Optional: ensure psql is available
if (-not (Get-Command psql -ErrorAction SilentlyContinue)) {
  Write-Error "psql not found on PATH. Install PostgreSQL client tools or add psql to PATH."
  exit 1
}

# Pass password to psql if provided
if ($Password) { $env:PGPASSWORD = $Password }

# Compute on/off without ternary (for older PS)
if ($Enable) { $val = 'on' } else { $val = 'off' }

# 1) ALTER SYSTEM must run alone (requires superuser)
Write-Host "Setting demo.canary_enabled = $val at system level..."
psql -h $HostName -p $Port -U $User -d $Database -X -w -v ON_ERROR_STOP=1 -c "ALTER SYSTEM SET demo.canary_enabled = '$val';"
if ($LASTEXITCODE -ne 0) {
  Write-Error "ALTER SYSTEM failed. Are you connected as a superuser? See output above."
  exit $LASTEXITCODE
}

# 2) Reload config in a separate call
Write-Host "Reloading PostgreSQL configuration..."
psql -h $HostName -p $Port -U $User -d $Database -X -w -v ON_ERROR_STOP=1 -c "SELECT pg_reload_conf();"
if ($LASTEXITCODE -ne 0) {
  Write-Error "pg_reload_conf() failed. See output above."
  exit $LASTEXITCODE
}

Write-Host ("Canary feature flag set to {0}" -f $Enable) -ForegroundColor Yellow



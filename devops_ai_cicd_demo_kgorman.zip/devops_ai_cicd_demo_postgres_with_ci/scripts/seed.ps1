<#
  Seed script for demo database
  - Loads customers from CSV using psql \copy (client-side)
  - Inserts random invoices per customer
#>

param(
  [string]${HostName} = 'localhost',
  [int]$Port = 5432,
  [string]$Database = 'demo',
  [string]$User = 'postgres',
  [string]$Password = $env:PGPASSWORD,
  # CHANGE THIS if your customers are in a different file:
  [string]$Csv = './seed/sample_invoices.csv'   # e.g., './seed/sample_customers.csv'
)

# Ensure psql is available
if (-not (Get-Command psql -ErrorAction SilentlyContinue)) {
  Write-Error "psql not found on PATH. Install PostgreSQL client tools or add psql to PATH."
  exit 1
}

# Verify seed file exists
if (-not (Test-Path $Csv)) {
  Write-Error "Seed file not found at $Csv"
  exit 1
}

# Set password for psql if provided
if ($Password) { $env:PGPASSWORD = $Password }

# Resolve absolute path and normalize slashes so Postgres reads it correctly
$csvPath = (Resolve-Path $Csv).Path -replace '\\','/'

# Build a single, well-quoted SQL command for psql
# NOTE: Confirm these columns match your CSV headers exactly.
$copySql = "\copy public.customers (customer_id, tenant_id, name) FROM '$csvPath' WITH (FORMAT csv, HEADER true);"

Write-Host "Seeding customers from CSV: $csvPath"
# -X ignore .psqlrc; -w no password prompt; -v ON_ERROR_STOP=1 fail fast
psql -h ${HostName} -p $Port -U $User -d $Database -X -w -v ON_ERROR_STOP=1 -c "$copySql"
if ($LASTEXITCODE -ne 0) {
  Write-Error "Customer seeding failed. See psql output above."
  exit $LASTEXITCODE
}

# Generate invoices (random amounts); adjust as needed
$insertInvoices = @"
insert into public.invoices(tenant_id, customer_id, amount)
select tenant_id, customer_id, (random()*1000)::numeric(12,2)
from public.customers
on conflict do nothing;
"@

Write-Host "Seeding invoices..."
psql -h ${HostName} -p $Port -U $User -d $Database -X -w -v ON_ERROR_STOP=1 -c "$insertInvoices"
if ($LASTEXITCODE -ne 0) {
  Write-Error "Invoice seeding failed. See psql output above."
  exit $LASTEXITCODE
}

# Optional: verify counts
$verifySql = @"
\t on
\pset footer off
select 'customers='||count(*) from public.customers;
select 'invoices='||count(*) from public.invoices;
"@

Write-Host "Verifying row counts..."
psql -h ${HostName} -p $Port -U $User -d $Database -X -w -v ON_ERROR_STOP=1 -c "$verifySql"

Write-Host "Seeding complete." -ForegroundColor Green

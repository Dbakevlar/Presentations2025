# Simple integrity check: compute SHA256 of migrations and compare with recorded values
$hashFile = "./migration_hashes.json"
$files = Get-ChildItem ../sql -Filter "V*__*.sql" | Sort-Object Name

function Get-Hash($path){
  $algo = [System.Security.Cryptography.SHA256]::Create()
  $bytes = [System.IO.File]::ReadAllBytes($path)
  ($algo.ComputeHash($bytes) | ForEach-Object { $_.ToString("x2") }) -join ""
}

$computed = @{}
foreach($f in $files){
  $computed[$f.Name] = Get-Hash $f.FullName
}

if (Test-Path $hashFile){
  $recorded = Get-Content $hashFile | ConvertFrom-Json
  $mismatch = @()
  foreach($k in $computed.Keys){
    if ($recorded[$k] -and $recorded[$k] -ne $computed[$k]){ $mismatch += $k }
  }
  if ($mismatch.Count -gt 0){
    Write-Error ("Hash mismatch detected: {0}. Aborting migration." -f ($mismatch -join ", "))
  } else {
    Write-Host "Migration integrity verified." -ForegroundColor Green
  }
} else {
  # First run, record hashes
  $computed | ConvertTo-Json | Set-Content $hashFile
  Write-Host "Recorded migration hashes for baseline." -ForegroundColor Yellow
}

param(
  [ValidateSet('All','AIReview','Governance','Migrate','Smoke','Observe')]
  [string]$Stage = 'All',
  [string]${HostName} = 'localhost',
  [int]$Port = 5432,
  [string]$Database = 'demo',
  [string]$User = 'postgres',
  [string]$Password = $env:PGPASSWORD,
  [int]$Target = 0, # 0 = latest
  [string]$FlywaySchemas = 'public',
  [string]$FYW_EXE = 'C:\Users\Kellyn.Gorman\Flyway\flyway-11.11.2\flyway' #'flyway' # override with full path if needed
)

$ErrorActionPreference = 'Stop'

function Invoke-PSQL($Sql){
  # Build args as an array to avoid quoting issues
  $psqlArgs = @(
    "-h", $HostName
    "-p", "$Port"
    "-U", $User
    "-d", $Database
    "-v", "ON_ERROR_STOP=1"
    "-t"     # tuples only
    "-A"     # unaligned
    "-X"     # ignore ~/.psqlrc
    "-w"     # never prompt for password
    "-c", $Sql
  )

  Write-Host ">> psql: $Sql" -ForegroundColor Cyan

  # Ensure password is available only for this call
  $old = $env:PGPASSWORD
  try {
    if ($Password) { $env:PGPASSWORD = $Password }
    & psql @psqlArgs
    if ($LASTEXITCODE -ne 0) {
      throw "psql exited with code $LASTEXITCODE"
    }
  }
  finally {
    $env:PGPASSWORD = $old
  }
}


function Time-Block($Label, [scriptblock]$Block){
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  try { & $Block } finally {
    $sw.Stop()
    Write-Host ("[TIME] {0} took {1} ms" -f $Label, $sw.ElapsedMilliseconds) -ForegroundColor Yellow
  }
}

# 0) Basic connection check
Time-Block "Connectivity check" { Invoke-PSQL "select version()" | Out-Null }

# 1) Optional AI review of pending changes
if ($Stage -eq 'All' -or $Stage -eq 'AIReview'){
  if (Get-Command .\scripts\ai-review.ps1 -ErrorAction SilentlyContinue) {
    .\scripts\ai-review.ps1
  } else { Write-Host "AI review skipped (no ai-review.ps1)" -ForegroundColor DarkYellow }
}

# 2) Governance guardrails: simple integrity check
if ($Stage -eq 'All' -or $Stage -eq 'Governance'){
  .\scripts\verify-hash.ps1
}

# 3) Run Flyway migrations (GitOps-style
if ($Stage -eq 'All' -or $Stage -eq 'Migrate') {
  $schemas = if ($FlywaySchemas) { ($FlywaySchemas -join ',') } else { '' }

  $flywayArgs = @(
    "migrate"  # keep the command explicit
    "-url=jdbc:postgresql://${HostName}:$Port/$Database"
    "-user=$User"
    # "-password=${Password}"  # prefer env var below
    "-locations=filesystem:../sql"
    "-schemas=$schemas"
  )

  # Safer: set env var instead of passing on CLI
  if ($Password) { $env:FLYWAY_PASSWORD = $Password }

  if ($Target -gt 0) { $flywayArgs += "-target=$Target" }

  Time-Block "Flyway migrate" { & $FYW_EXE @flywayArgs }
}

# 4) Smoke tests
if ($Stage -eq 'All' -or $Stage -eq 'Smoke') {
  $checks = @(
    "select to_regclass('public.customers') is not null as has_customers;"
    "select to_regclass('public.invoices')  is not null as has_invoices;"
    "select relrowsecurity from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname='invoices';"
  )
  foreach ($c in $checks) {
    # assuming Invoke-PSQL wraps: psql -d $Database -U $User -c "$c"
    Invoke-PSQL $c | ForEach-Object { Write-Host $_ }
  }
}

# 5) Observability (basic): show top statements if pg_stat_statements exists
if ($Stage -eq 'All' -or $Stage -eq 'Observe'){
  try {
    Invoke-PSQL "create extension if not exists pg_stat_statements;" | Out-Null
    Invoke-PSQL "select query, calls, total_exec_time from pg_stat_statements order by total_exec_time desc limit 5;"
  } catch {
    Write-Host "pg_stat_statements unavailable (requires superuser). Skipping." -ForegroundColor DarkYellow
  }
}

Write-Host "`nPipeline complete." -ForegroundColor Green

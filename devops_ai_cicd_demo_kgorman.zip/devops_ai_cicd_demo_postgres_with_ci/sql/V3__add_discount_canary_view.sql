-- V3__add_discount_canary_view.sql
-- Canary: introduce a discounted view for a subset of users
-- Feature flag using GUC: demo.canary_enabled = on/off in postgresql.auto.conf
create or replace function public.canary_enabled() returns boolean
language sql immutable as $$
  select current_setting('demo.canary_enabled', true) = 'on'
$$;

create or replace view public.v_invoices_current as
select i.invoice_id,
       i.tenant_id,
       i.customer_id,
       case when public.canary_enabled() then (i.amount * 0.95)::numeric(12,2) else i.amount end as effective_amount,
       i.created_at
from public.invoices i;

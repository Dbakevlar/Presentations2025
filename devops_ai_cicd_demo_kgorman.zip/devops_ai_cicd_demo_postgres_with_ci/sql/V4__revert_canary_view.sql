-- V4__revert_canary_view.sql
-- Roll forward to revert: disable discount logic by removing canary predicate
create or replace view public.v_invoices_current as
select i.invoice_id,
       i.tenant_id,
       i.customer_id,
       i.amount as effective_amount,
       i.created_at
from public.invoices i;

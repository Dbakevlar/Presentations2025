-- V2__rls_and_policies.sql
alter table public.invoices enable row level security;
-- Policy: tenants only see their own invoices
drop policy if exists tenant_isolation on public.invoices;
create policy tenant_isolation on public.invoices
  for select
  using (tenant_id = current_setting('app.tenant_id', true));

-- Force tenant_id tagging on insert/update if needed (example)
drop policy if exists tenant_enforce on public.invoices;
create policy tenant_enforce on public.invoices
  for insert with check (tenant_id = current_setting('app.tenant_id', true));

-- Helper function to set tenant for this session
create or replace function public.set_tenant(tenant text) returns void language plpgsql as $$
begin
  perform set_config('app.tenant_id', tenant, false);
end; $$;

-- Index for common query pattern
create index if not exists idx_invoices_tenant_created on public.invoices(tenant_id, created_at desc);

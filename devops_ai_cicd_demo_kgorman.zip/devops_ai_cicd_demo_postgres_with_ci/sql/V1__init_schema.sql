-- V1__init_schema.sql
create table if not exists public.customers(
  customer_id serial primary key,
  tenant_id   text not null,
  name        text not null,
  unique (tenant_id, customer_id)
);

create table if not exists public.invoices(
  invoice_id  bigserial primary key,
  tenant_id   text not null,
  customer_id int references public.customers(customer_id),
  amount      numeric(12,2) not null,
  created_at  timestamptz default now(),
  constraint invoices_tenant_fk check (tenant_id <> '')
);

-- minimal read role (principle of least privilege)
do $$
begin
  if not exists (select from pg_roles where rolname='app_readonly') then
    create role app_readonly;
  end if;
end $$;

grant usage on schema public to app_readonly;
grant select on public.customers, public.invoices to app_readonly;

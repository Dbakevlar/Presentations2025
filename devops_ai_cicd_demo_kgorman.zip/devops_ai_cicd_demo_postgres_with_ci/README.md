
CloudX Demo Scripts
Kellyn Gorman, Engineer and Advocate at Redgate

Prep/Prerequisite
-Ensure Postgres is running and has a demo database. If needed, set $env:PGPASSWORD.
-Unzip project; ensure psql and flyway are on PATH (or set FYW_EXE in scripts).
-createdb -h localhost -U postgres demo
$env:PGPASSWORD = "<password>"
-The pg_stat_statements extension must be installed/configured
-Have Ollama for Windows 11 installed and configured
-After downloading the scripts, you may have to unblock the scripts in each of the file properties due to security in Windows.

Demo 1) Pipeline (Governance Migrate Smoke Observe) (34 min)
.\scripts\run.ps1
Governance: verify-hash.ps1 checks SHA-256 of migrations.
Migrate: Flyway applies sql/V1..V4 (GitOps-style versioned migrations).
Smoke: Confirms objects exist and RLS is enabled on invoices.
Observe: Stage timings; tries pg_stat_statements (skips if not permitted).

Demo 2) Seed & Prove RLS 23 min
.\scripts\seed.ps1
psql -h localhost -U postgres -d demo -c "select public.set_tenant(’tenant_a’); select count(*) from public.invoices;"
psql -h localhost -U postgres -d demo -c "select public.set_tenant(’tenant_b’); select count(*) from public.invoices;"

•	Policy uses current_setting(’app.tenant_id’); helper set_tenant() sets per session.
•	Least-privilege role app_readonly granted SELECT only.

Demo 3) Progressive Delivery via Feature Flag (Canary) (23 min)
.\scripts\toggle-canary.ps1 -Enable:$true
psql -h localhost -U postgres -d demo -c "select public.set_tenant(’tenant_a’); select invoice_id, amount, effective_amount from public.v_invoices_current limit 5;"
.\scripts\toggle-canary.ps1 -Enable:$false
psql -h localhost -U postgres -d demo -c "select invoice_id, amount, effective_amount from public.v_invoices_current limit 5;"

•	V3 adds v_invoices_current with 5% discount when demo.canary_enabled=on.
•	V4 reverts via roll-forward (safe rollback pattern).

Demo 4 (Optional) CI & GitOps (2 min)
CI: review .github/workflows/ci.yml (Postgres service integrity migrate smoke canary).
act -W .github/workflows/ci.yml -j ci --secret PGPASSWORD=postgres
GitOps (preview only):
.\ops\scripts\render-kustomize.ps1 -Overlay stable
.\ops\scripts\render-kustomize.ps1 -Overlay canary
Troubleshooting
Auth: set $env:PGPASSWORD or pass -Password to scripts.
Flyway not found: set FYW_EXE in scripts\run.ps1.
pg_stat_statements warning: needs superuser; safe to ignore in demo.
Custom port: pass -Port 5432 to scripts.	
“ps1 is not digitally signed”:  Right click on each file to run these powershell scripts in your own secluded test environment and choose to “unblock” from the general properties:
 
File Map
•	sql/V1..V4 schema, RLS, feature-flag view, revert
•	scripts/verify-hash.ps1 integrity guardrails
•	scripts/ai-review.ps1 optional Ollama LLM review
•	.github/workflows/ci.yml CI mirrors local pipeline
•	app/k8s/overlays/* stable vs canary (Kustomize)

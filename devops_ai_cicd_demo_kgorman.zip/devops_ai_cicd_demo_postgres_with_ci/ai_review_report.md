### V1__init_schema.sql

- **Security**: Missing Row-Level Security (RLS) on the `customers` table.
- **Performance**: No indexes created.
- **Rollback**: Grants are not explicitly reverted in the schema file, which can lead to permission issues if schema is dropped and recreated.
- **Correctness**: The `unique (tenant_id, customer_id)` constraint is unnecessary as `customer_id` is a primary key already.
- **Deployment Risk**: Creating roles without considering potential security implications.

**Flag:** REVIEW

### V2__rls_and_policies.sql

- **Security**: RLS is enabled on the `invoices` table with policies for tenant isolation and tagging, which helps enforce the principle of least privilege.
- **Performance**: An index is created on a common query pattern (`idx_invoices_tenant_created`), which can improve performance for select queries filtering by `tenant_id`.
- **Rollback**: Policies and functions are not explicitly reverted in the schema file, which can lead to permission issues if schema is dropped and recreated.
- **Correctness**: The function `set_tenant` sets a configuration value that can be used within sessions. This is a common approach for managing session-level settings.
- **Deployment Risk**: No explicit rollback logic provided, which could leave the database in an inconsistent state.

**Flag:** REVIEW

### V3__add_discount_canary_view.sql

- **Security**: Feature flag using GUC (`demo.canary_enabled`) to control view behavior. This approach can be risky if not managed properly.
- **Performance**: No indexes are created.
- **Rollback**: The `canary_enabled` function and view creation are not explicitly reverted, which could leave the database in an inconsistent state.
- **Correctness**: The view uses a feature flag to conditionally apply a discount. This is a reasonable approach if managed carefully.
- **Deployment Risk**: No explicit rollback logic provided.

**Flag:** REVIEW

### V4__revert_canary_view.sql

- **Security**: No specific security implications noted.
- **Performance**: No indexes are created.
- **Rollback**: The view creation is not explicitly reverted, which could leave the database in an inconsistent state.
- **Correctness**: Reverting the canary view to its original form is straightforward.
- **Deployment Risk**: No explicit rollback logic provided.

**Flag:** REVIEW


### File: V1__init_schema.sql
- **Security Issues**: Minimal read role `app_readonly` created but lacks proper RLS policies.
- **Performance Pitfalls**: No obvious performance issues, but ensure `tenant_id` uniqueness index is beneficial.
- **Rollback/Reversibility Notes**: DROPs and CREATEs are idempotent in this case.
- **Correctness and Deployment Risk**: Minor risk if roles already exist; otherwise, safe.

**Flag: REVIEW**

### File: V2__rls_and_policies.sql
- **Security Issues**: Appropriate RLS policies added. `app_readonly` lacks access to `invoices`.
- **Performance Pitfalls**: Index on `(tenant_id, created_at desc)` may not be beneficial without frequent queries involving this pattern.
- **Rollback/Reversibility Notes**: DROPs and CREATEs are idempotent.
- **Correctness and Deployment Risk**: Low risk, but ensure RLS policies align with application needs.

**Flag: PASS**

### File: V3__add_discount_canary_view.sql
- **Security Issues**: No specific security concerns noted.
- **Performance Pitfalls**: Adding a view may impact performance depending on query usage. Ensure it's necessary.
- **Rollback/Reversibility Notes**: Drop the function and view, reverting to original state.
- **Correctness and Deployment Risk**: Can introduce bugs if not tested thoroughly.

**Flag: REVIEW**

### File: V4__revert_canary_view.sql
- **Security Issues**: No specific security concerns noted.
- **Performance Pitfalls**: Dropping a view is generally low risk, but ensure no dependent queries are affected.
- **Rollback/Reversibility Notes**: Drop the function and view, reverting to original state.
- **Correctness and Deployment Risk**: Low risk, but ensure it aligns with rollback strategy.

**Flag: PASS**


param(
  [string]$HostName,
  [int]$Port,
  [string]$Database,
  [string]$User,
  [string]$Password
)

# Optional AI-assisted review using Ollama if installed
$ollama = Get-Command ollama -ErrorAction SilentlyContinue
if (-not $ollama) {
  Write-Host "Ollama not found. Skipping AI review." -ForegroundColor DarkYellow
  exit 0
}

$model = $env:AI_REVIEW_MODEL
if (-not $model) { $model = "qwen2.5-coder" }  # choose any local model you have

# Gather SQL diffs (new files)
$files = Get-ChildItem ../sql -Filter "V*__*.sql" | Sort-Object Name
$summary = @()
foreach($f in $files){
  $content = Get-Content $f.FullName -Raw
  $summary += "### File: $($f.Name)`n````sql`n$content`n````"
}
$prompt = @"
You are an expert database reviewer. Analyze these PostgreSQL migration files for:
- security issues (e.g., missing RLS, overly broad grants)
- performance pitfalls (missing indexes, risky scans)
- rollback/reversibility notes
- correctness and deployment risk

Respond with concise bullet points and a PASS/REVIEW flag per file.
$($summary -join "`n`n")
"@

Write-Host "Running AI review with model '$model'..." -ForegroundColor Cyan
$result = & ollama run $model $prompt
$result | Set-Content -Path ./ai_review_report.md
Write-Host "AI review written to ./ai_review_report.md" -ForegroundColor Green

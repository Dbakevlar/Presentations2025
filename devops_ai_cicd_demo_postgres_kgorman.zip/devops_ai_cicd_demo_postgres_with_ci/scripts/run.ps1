param(
  [ValidateSet('All','AIReview','Governance','Migrate','Smoke','Observe')]
  [string]$Stage = 'All',
  [string]${HostName} = 'localhost',
  [int]$Port = 5432,
  [string]$Database = 'demo',
  [string]$User = 'postgres',
  [string]$Password = $env:PGPASSWORD,
  [int]$Target = 0,
  [string]$FlywaySchemas = 'public',
  [string]$FYW_EXE = 'C:\Users\Kellyn.Gorman\Flyway\flyway-11.11.2\flyway'
)

$ErrorActionPreference = 'Stop'

# Always resolve relative paths from THIS script's directory
$ScriptRoot  = Split-Path -Parent $MyInvocation.MyCommand.Path
$scriptsPath = Join-Path $ScriptRoot 'scripts'

function Invoke-PSQL($Sql){
  $psqlArgs = @(
    "-h", $HostName
    "-p", "$Port"
    "-U", $User
    "-d", $Database
    "-v", "ON_ERROR_STOP=1"
    "-t"
    "-A"
    "-X"
    "-w"
    "-c", $Sql
  )
  Write-Host ">> psql: $Sql" -ForegroundColor Cyan
  $old = $env:PGPASSWORD
  try {
    if ($Password) { $env:PGPASSWORD = $Password }
    & psql @psqlArgs
    if ($LASTEXITCODE -ne 0) { throw "psql exited with code $LASTEXITCODE" }
  } finally { $env:PGPASSWORD = $old }
}

function Time-Block($Label, [scriptblock]$Block){
  $sw = [System.Diagnostics.Stopwatch]::StartNew()
  try { & $Block } finally {
    $sw.Stop()
    Write-Host ("[TIME] {0} took {1} ms" -f $Label, $sw.ElapsedMilliseconds) -ForegroundColor Yellow
  }
}

# Helper to run a child script by name in .\scripts, with timing and friendly skip message
function Run-Child {
  param(
    [Parameter(Mandatory)] [string]$Name,
    [Parameter()] [object]$Args = $null
  )

  $child = Join-Path $scriptsPath $Name
  if (-not (Test-Path -LiteralPath $child)) {
    Write-Host "$Name skipped (not found at $child)" -ForegroundColor DarkYellow
    return
  }

  # Normalize Args -> Hashtable (handles null, Object[], etc.)
  $ht = @{}
  if ($Args -is [hashtable]) {
    $ht = $Args
  } elseif ($Args -is [System.Collections.IDictionary]) {
    $ht = @{} + $Args
  } elseif ($Args -is [object[]]) {
    foreach ($a in $Args) {
      if ($a -is [hashtable]) { $ht += $a }
    }
  }

  try {
    Unblock-File -LiteralPath $child -ErrorAction SilentlyContinue | Out-Null
    if ($ht.Count -gt 0) { & $child @ht } else { & $child }
  } catch {
    throw "Child script '$Name' failed: $($_.Exception.Message)"
  }
}

# 0) Basic connection check
Time-Block "Connectivity check" { Invoke-PSQL "select version()" | Out-Null }

# 1) AI review
if ($Stage -eq 'All' -or $Stage -eq 'AIReview'){
  Run-Child 'ai-review.ps1' @{
    HostName = $HostName; Port = $Port; Database = $Database; User = $User; Password = $Password
  }
}

# 2) Governance guardrails
if ($Stage -eq 'All' -or $Stage -eq 'Governance'){
  Run-Child 'verify-hash.ps1'
}

# 3) Flyway migrate
if ($Stage -eq 'All' -or $Stage -eq 'Migrate') {
  $schemas = if ($FlywaySchemas) { ($FlywaySchemas -join ',') } else { '' }
  $flywayArgs = @(
    "migrate"
    "-url=jdbc:postgresql://${HostName}:$Port/$Database"
    "-user=$User"
    "-locations=filesystem:../sql"
    "-schemas=$schemas"
  )
  if ($Password) { $env:FLYWAY_PASSWORD = $Password }
  if ($Target -gt 0) { $flywayArgs += "-target=$Target" }
  Time-Block "Flyway migrate" { & $FYW_EXE @flywayArgs }
}

# 4) Smoke tests
if ($Stage -eq 'All' -or $Stage -eq 'Smoke') {
  $checks = @(
    "select to_regclass('public.customers') is not null as has_customers;"
    "select to_regclass('public.invoices')  is not null as has_invoices;"
    "select relrowsecurity from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname='invoices';"
  )
  foreach ($c in $checks) { Invoke-PSQL $c | ForEach-Object { Write-Host $_ } }
}

# 5) Observability
if ($Stage -eq 'All' -or $Stage -eq 'Observe'){
  try {
    Invoke-PSQL "create extension if not exists pg_stat_statements;" | Out-Null
    Invoke-PSQL "select query, calls, total_exec_time from pg_stat_statements order by total_exec_time desc limit 5;"
  } catch {
    Write-Host "pg_stat_statements unavailable (requires superuser). Skipping." -ForegroundColor DarkYellow
  }
}

Write-Host "`nPipeline complete." -ForegroundColor Green
